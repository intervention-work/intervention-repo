<?php
/**
 * Plugin Name:  Intervention Headless Setup
 * Plugin URI:   https://intervention.com
 * Description:  Registers the detail_page CPT and all ACF field groups required for the headless Next.js migration. Requires ACF PRO. Adds SEO (Rank Math) + redirects bridge endpoints.
 * Version:      2.2.0
 * Author:       Intervention.com
 */

if ( ! defined( 'ABSPATH' ) ) exit;

// ---------------------------------------------------------------------------
// 1. Register the detail_page Custom Post Type
// ---------------------------------------------------------------------------
add_action( 'init', function () {
    register_post_type( 'detail_page', [
        'label'        => 'Detail Pages',
        'labels'       => [
            'name'          => 'Detail Pages',
            'singular_name' => 'Detail Page',
            'add_new_item'  => 'Add New Detail Page',
            'edit_item'     => 'Edit Detail Page',
        ],
        'public'       => false,
        'show_ui'      => true,
        'show_in_menu' => true,
        'show_in_rest' => true,
        'rest_base'    => 'detail_page',
        'has_archive'  => false,
        'supports'     => [ 'title', 'custom-fields', 'page-attributes' ],
        'rewrite'      => false,
    ] );
} );

// ---------------------------------------------------------------------------
// 2. Register ACF Options Page
// ---------------------------------------------------------------------------
add_action( 'acf/init', function () {
    if ( function_exists( 'acf_add_options_page' ) ) {
        acf_add_options_page( [
            'page_title' => 'Global Settings',
            'menu_title' => 'Global Settings',
            'menu_slug'  => 'global-settings',
            'capability' => 'manage_options',
            'redirect'   => false,
        ] );
    }
} );

// ---------------------------------------------------------------------------
// 2b. Expose Global Settings via a custom REST endpoint
//     GET /wp-json/intervention/v1/settings
//     (ACF options pages are not exposed through core REST.)
// ---------------------------------------------------------------------------
add_action( 'rest_api_init', function () {
    register_rest_route( 'intervention/v1', '/settings', [
        'methods'             => 'GET',
        'permission_callback' => '__return_true',
        'callback'            => function () {
            // Prevent WP Engine / CDN edge caching so option edits appear immediately.
            nocache_headers();
            $response = new WP_REST_Response();
            $response->header( 'Cache-Control', 'no-cache, no-store, must-revalidate' );

            $get = function ( $name ) {
                return function_exists( 'get_field' ) ? ( get_field( $name, 'option' ) ?: '' ) : '';
            };
            $response->set_data( [
                'phone_display' => $get( 'phone_display' ),
                'phone_href'    => $get( 'phone_href' ),
                'email'         => $get( 'email' ),
            ] );
            return $response;
        },
    ] );

    // -----------------------------------------------------------------------
    // Expose the WordPress nav menu(s) so the headless site renders the exact
    // menu marketing manages under Appearance > Menus.
    //   GET /wp-json/intervention/v1/nav          (primary/first menu)
    //   GET /wp-json/intervention/v1/nav?menu=Foo (menu by name/slug/location)
    // Returns a nested tree: [{ id, label, url, target, children: [...] }]
    // -----------------------------------------------------------------------
    register_rest_route( 'intervention/v1', '/nav', [
        'methods'             => 'GET',
        'permission_callback' => '__return_true',
        'callback'            => function ( $request ) {
            nocache_headers();

            $requested = $request->get_param( 'menu' );
            $menu_id   = 0;

            // 1) explicit ?menu= (location, slug, name, or id)
            if ( $requested ) {
                $locations = get_nav_menu_locations();
                if ( isset( $locations[ $requested ] ) ) {
                    $menu_id = $locations[ $requested ];
                } else {
                    $obj = wp_get_nav_menu_object( $requested );
                    if ( $obj ) $menu_id = $obj->term_id;
                }
            }

            // 2) common primary locations
            if ( ! $menu_id ) {
                $locations = get_nav_menu_locations();
                foreach ( [ 'primary', 'main', 'menu-1', 'header', 'primary-menu' ] as $loc ) {
                    if ( ! empty( $locations[ $loc ] ) ) { $menu_id = $locations[ $loc ]; break; }
                }
            }

            // 3) first menu that exists
            if ( ! $menu_id ) {
                $menus = wp_get_nav_menus();
                if ( ! empty( $menus ) ) $menu_id = $menus[0]->term_id;
            }

            $items = $menu_id ? wp_get_nav_menu_items( $menu_id ) : [];
            if ( ! $items ) $items = [];

            // Build a flat map then nest by menu_item_parent.
            $home = home_url();
            $to_relative = function ( $url ) use ( $home ) {
                if ( ! $url ) return '#';
                $u = str_replace( $home, '', $url );
                return $u === '' ? '/' : $u;
            };

            $nodes = [];
            foreach ( $items as $it ) {
                $nodes[ $it->ID ] = [
                    'id'       => (int) $it->ID,
                    'parent'   => (int) $it->menu_item_parent,
                    'label'    => $it->title,
                    'url'      => $to_relative( $it->url ),
                    'target'   => $it->target ?: '',
                    'children' => [],
                ];
            }
            $tree = [];
            foreach ( $nodes as $id => &$node ) {
                if ( $node['parent'] && isset( $nodes[ $node['parent'] ] ) ) {
                    $nodes[ $node['parent'] ]['children'][] = &$node;
                } else {
                    $tree[] = &$node;
                }
            }
            unset( $node );

            $response = new WP_REST_Response( array_values( $tree ) );
            $response->header( 'Cache-Control', 'no-cache, no-store, must-revalidate' );
            return $response;
        },
    ] );

    // -----------------------------------------------------------------------
    // SEO bridge: expose the editor-set Rank Math SEO fields for one page/post
    // so the headless site can honour the exact title/description/canonical/OG
    // marketing sets in WordPress (Rank Math does not put these in /wp/v2 by
    // default). Template variables like %title% %sep% %sitename% are resolved.
    //   GET /wp-json/intervention/v1/seo?type=post|page&slug=my-article
    // Returns {} when nothing is set, so the frontend falls back to defaults.
    // -----------------------------------------------------------------------
    register_rest_route( 'intervention/v1', '/seo', [
        'methods'             => 'GET',
        'permission_callback' => '__return_true',
        'callback'            => function ( $request ) {
            nocache_headers();
            $response = new WP_REST_Response();
            $response->header( 'Cache-Control', 'no-cache, no-store, must-revalidate' );

            $type = $request->get_param( 'type' ) === 'post' ? 'post' : 'page';
            $slug = sanitize_title( (string) $request->get_param( 'slug' ) );
            if ( ! $slug ) { $response->set_data( new stdClass() ); return $response; }

            $found = get_posts( [
                'name'        => $slug,
                'post_type'   => $type,
                'post_status' => 'publish',
                'numberposts' => 1,
            ] );
            if ( empty( $found ) ) { $response->set_data( new stdClass() ); return $response; }

            $post = $found[0];
            $id   = $post->ID;
            $meta = function ( $key ) use ( $id ) { return (string) get_post_meta( $id, $key, true ); };
            $resolve = function ( $text ) use ( $post ) {
                if ( $text && class_exists( '\\RankMath\\Helper' ) && method_exists( '\\RankMath\\Helper', 'replace_vars' ) ) {
                    return \RankMath\Helper::replace_vars( $text, $post );
                }
                return $text;
            };

            $data = array_filter( [
                'title'          => $resolve( $meta( 'rank_math_title' ) ),
                'description'    => $resolve( $meta( 'rank_math_description' ) ),
                'canonical'      => $meta( 'rank_math_canonical_url' ),
                'og_title'       => $resolve( $meta( 'rank_math_facebook_title' ) ),
                'og_description' => $resolve( $meta( 'rank_math_facebook_description' ) ),
                'og_image'       => $meta( 'rank_math_facebook_image' ),
                'twitter_image'  => $meta( 'rank_math_twitter_image' ),
            ], function ( $v ) { return $v !== '' && $v !== null; } );

            $response->set_data( empty( $data ) ? new stdClass() : $data );
            return $response;
        },
    ] );

    // -----------------------------------------------------------------------
    // Redirects export: expose the Rank Math Redirections so the headless site
    // can apply the same redirects marketing manages in WordPress.
    //   GET /wp-json/intervention/v1/redirects
    // Returns [{ from, to, code }]. Empty when Rank Math redirects are unused.
    // -----------------------------------------------------------------------
    register_rest_route( 'intervention/v1', '/redirects', [
        'methods'             => 'GET',
        'permission_callback' => '__return_true',
        'callback'            => function () {
            global $wpdb;
            nocache_headers();
            $out   = [];
            $table = $wpdb->prefix . 'rank_math_redirections';
            $exists = $wpdb->get_var( $wpdb->prepare( 'SHOW TABLES LIKE %s', $table ) );
            if ( $exists === $table ) {
                $rows = $wpdb->get_results( "SELECT sources, url_to, header_code FROM {$table} WHERE status = 'active'" );
                foreach ( (array) $rows as $r ) {
                    $sources = maybe_unserialize( $r->sources );
                    if ( ! is_array( $sources ) ) continue;
                    foreach ( $sources as $src ) {
                        $pattern = is_array( $src ) ? ( isset( $src['pattern'] ) ? $src['pattern'] : '' ) : '';
                        if ( ! $pattern ) continue;
                        $out[] = [
                            'from' => '/' . ltrim( $pattern, '/' ),
                            'to'   => $r->url_to,
                            'code' => (int) $r->header_code ?: 301,
                        ];
                    }
                }
            }
            $response = new WP_REST_Response( $out );
            $response->header( 'Cache-Control', 'no-cache, no-store, must-revalidate' );
            return $response;
        },
    ] );
} );

// ---------------------------------------------------------------------------
// 2c. On-demand ISR revalidation — ping Next.js when content changes
//     so edits appear immediately instead of waiting on the ISR window.
// ---------------------------------------------------------------------------
function ihs_ping_revalidate( $paths = [], $layout = false ) {
    if ( ! function_exists( 'get_field' ) ) return;
    $base   = get_field( 'revalidate_url', 'option' );
    $secret = get_field( 'revalidate_secret', 'option' );
    if ( ! $base || ! $secret ) return; // not configured yet

    $query = [ 'secret' => $secret ];
    $paths = array_filter( (array) $paths );
    if ( $paths )  $query['path']   = implode( ',', $paths );
    if ( $layout ) $query['layout'] = '1';

    $endpoint = trailingslashit( $base ) . 'api/revalidate?' . http_build_query( $query );
    wp_remote_post( $endpoint, [ 'timeout' => 5, 'blocking' => false ] );
}

// Compute the paths to revalidate for a given post, and fire the ping.
// Handles the three content types the site renders and their listing pages so
// adds, edits, unpublishes and deletes all propagate — not just publishes.
function ihs_revalidate_for_post( $post ) {
    if ( ! $post instanceof WP_Post ) return;

    switch ( $post->post_type ) {
        case 'page':
            // Full hierarchical path (get_page_uri handles nested/child pages
            // like /interventionists-by-state/california). Nav may change → layout.
            $uri = get_page_uri( $post );
            $path = $uri ? '/' . $uri : '/' . $post->post_name;
            ihs_ping_revalidate( [ $path ], true );
            break;

        case 'detail_page':
            $parent = get_field( 'parent_section', $post->ID );
            $slug   = get_field( 'slug', $post->ID );
            $paths  = [];
            if ( $parent && $slug ) {
                $paths[] = '/' . $parent . '/' . $slug; // the detail page
                $paths[] = '/' . $parent;               // the section landing grid
            }
            ihs_ping_revalidate( $paths, true );
            break;

        case 'post':
            // Blog article: its own page + the blog index listing.
            ihs_ping_revalidate(
                [ '/intervention-blog/' . $post->post_name, '/intervention-blog' ],
                false
            );
            break;
    }
}

// 1) Content saved/published (edits + new publishes).
add_action( 'save_post', function ( $post_id, $post ) {
    if ( wp_is_post_revision( $post_id ) || wp_is_post_autosave( $post_id ) ) return;
    if ( $post->post_status !== 'publish' ) return;
    ihs_revalidate_for_post( $post );
}, 20, 2 );

// 2) Status transitions crossing the publish boundary (new publish, unpublish,
//    move to trash). Covers removal from the live site.
add_action( 'transition_post_status', function ( $new_status, $old_status, $post ) {
    if ( $new_status === $old_status ) return;
    if ( $new_status !== 'publish' && $old_status !== 'publish' ) return;
    ihs_revalidate_for_post( $post );
}, 20, 3 );

// 3) Permanent deletion (ACF fields + slug still readable in before_delete).
add_action( 'before_delete_post', function ( $post_id ) {
    ihs_revalidate_for_post( get_post( $post_id ) );
}, 20 );

// 4) Global Settings options page (phone/email affect nav + footer everywhere).
add_action( 'acf/save_post', function ( $post_id ) {
    if ( $post_id === 'options' ) {
        ihs_ping_revalidate( [], true );
    }
}, 20 );

// 5) WP nav menu edited (nav is WordPress-menu-driven) → refresh the layout.
add_action( 'wp_update_nav_menu', function () {
    ihs_ping_revalidate( [], true );
}, 20 );

// ---------------------------------------------------------------------------
// 3. Import ACF Field Groups into the database (runs once on admin load)
//    Uses acf_import_field_group() which writes to the DB like the ACF UI does.
// ---------------------------------------------------------------------------
add_action( 'admin_init', function () {
    if ( ! function_exists( 'acf_import_field_group' ) ) return;
    if ( get_option( 'ihs_field_groups_v200_imported' ) ) return;

    // -----------------------------------------------------------------------
    // Group 1: Section Page — applied to all WP Pages
    // -----------------------------------------------------------------------
    acf_import_field_group( [
        'key'         => 'group_ihs_section_page',
        'title'       => 'Section Page',
        'active'      => true,
        'show_in_rest' => 1,
        'fields'   => [
            [ 'key' => 'field_sp_label',            'name' => 'label',            'label' => 'Label (nav / card text)',    'type' => 'text' ],
            [ 'key' => 'field_sp_eyebrow',          'name' => 'eyebrow',          'label' => 'Eyebrow (hero kicker, optional)', 'type' => 'text' ],
            [ 'key' => 'field_sp_title',            'name' => 'title',            'label' => 'Title (H1)',                 'type' => 'text' ],
            [ 'key' => 'field_sp_summary',          'name' => 'summary',          'label' => 'Summary (meta description)', 'type' => 'textarea' ],
            [ 'key' => 'field_sp_intro',            'name' => 'intro',            'label' => 'Intro paragraph',            'type' => 'textarea' ],
            [
                'key'           => 'field_sp_image',
                'name'          => 'image',
                'label'         => 'Hero Image',
                'type'          => 'image',
                'return_format' => 'url',
                'preview_size'  => 'medium',
            ],
            [
                'key'          => 'field_sp_source_page_slug',
                'name'         => 'source_page_slug',
                'label'        => 'Body content source (optional)',
                'type'         => 'text',
                'instructions' => 'Leave blank — the page body pulls from the WP page with this same slug. Set only when the content lives on a differently-named WP page (e.g. about-us).',
            ],
            [ 'key' => 'field_sp_children_eyebrow', 'name' => 'childrenEyebrow', 'label' => 'Children Eyebrow', 'type' => 'text' ],
            [ 'key' => 'field_sp_children_title',   'name' => 'childrenTitle',   'label' => 'Children Title',   'type' => 'text' ],
            [
                'key'          => 'field_sp_content_blocks',
                'name'         => 'content_blocks',
                'label'        => 'Content Blocks',
                'type'         => 'flexible_content',
                'button_label' => 'Add Block',
                'layouts'      => [
                    [
                        'key'        => 'layout_sp_body_block',
                        'name'       => 'body_block',
                        'label'      => 'Body Block',
                        'sub_fields' => [
                            [ 'key' => 'field_sp_bb_heading', 'name' => 'heading', 'label' => 'Heading', 'type' => 'text' ],
                            [ 'key' => 'field_sp_bb_body',    'name' => 'body',    'label' => 'Body',    'type' => 'textarea', 'instructions' => 'Newline = new paragraph.' ],
                        ],
                    ],
                    [
                        'key'        => 'layout_sp_bullets_block',
                        'name'       => 'bullets_block',
                        'label'      => 'Bullets Block',
                        'sub_fields' => [
                            [ 'key' => 'field_sp_bub_heading', 'name' => 'heading', 'label' => 'Heading',                    'type' => 'text' ],
                            [ 'key' => 'field_sp_bub_body',    'name' => 'body',    'label' => 'Intro paragraph (optional)', 'type' => 'textarea' ],
                            [
                                'key'          => 'field_sp_bub_bullets',
                                'name'         => 'bullets',
                                'label'        => 'Bullets',
                                'type'         => 'repeater',
                                'button_label' => 'Add Bullet',
                                'sub_fields'   => [
                                    [ 'key' => 'field_sp_bub_item', 'name' => 'item', 'label' => 'Item', 'type' => 'text' ],
                                ],
                            ],
                        ],
                    ],
                    [
                        'key'        => 'layout_sp_stats_block',
                        'name'       => 'stats_block',
                        'label'      => 'Stats Block',
                        'sub_fields' => [
                            [ 'key' => 'field_sp_stb_heading', 'name' => 'heading', 'label' => 'Heading', 'type' => 'text' ],
                            [ 'key' => 'field_sp_stb_body',    'name' => 'body',    'label' => 'Intro paragraph (optional)', 'type' => 'textarea' ],
                            [
                                'key'          => 'field_sp_stb_stats',
                                'name'         => 'stats',
                                'label'        => 'Stats',
                                'type'         => 'repeater',
                                'button_label' => 'Add Stat',
                                'sub_fields'   => [
                                    [ 'key' => 'field_sp_stb_value', 'name' => 'value', 'label' => 'Value', 'type' => 'text' ],
                                    [ 'key' => 'field_sp_stb_label', 'name' => 'label', 'label' => 'Label', 'type' => 'text' ],
                                ],
                            ],
                        ],
                    ],
                    [
                        'key'        => 'layout_sp_features_block',
                        'name'       => 'features_block',
                        'label'      => 'Features Block',
                        'sub_fields' => [
                            [ 'key' => 'field_sp_fb_heading', 'name' => 'heading', 'label' => 'Heading', 'type' => 'text' ],
                            [ 'key' => 'field_sp_fb_body',    'name' => 'body',    'label' => 'Intro paragraph (optional)', 'type' => 'textarea' ],
                            [
                                'key'          => 'field_sp_fb_features',
                                'name'         => 'features',
                                'label'        => 'Features',
                                'type'         => 'repeater',
                                'button_label' => 'Add Feature',
                                'sub_fields'   => [
                                    [ 'key' => 'field_sp_fb_feat_title', 'name' => 'title', 'label' => 'Title', 'type' => 'text' ],
                                    [ 'key' => 'field_sp_fb_feat_body',  'name' => 'body',  'label' => 'Body',  'type' => 'textarea' ],
                                ],
                            ],
                        ],
                    ],
                    [
                        'key'        => 'layout_sp_steps_block',
                        'name'       => 'steps_block',
                        'label'      => 'Steps Block',
                        'sub_fields' => [
                            [ 'key' => 'field_sp_sb_heading', 'name' => 'heading', 'label' => 'Heading', 'type' => 'text' ],
                            [ 'key' => 'field_sp_sb_body',    'name' => 'body',    'label' => 'Intro paragraph (optional)', 'type' => 'textarea' ],
                            [
                                'key'          => 'field_sp_sb_steps',
                                'name'         => 'steps',
                                'label'        => 'Steps',
                                'type'         => 'repeater',
                                'button_label' => 'Add Step',
                                'sub_fields'   => [
                                    [ 'key' => 'field_sp_sb_step_title', 'name' => 'title', 'label' => 'Title', 'type' => 'text' ],
                                    [ 'key' => 'field_sp_sb_step_body',  'name' => 'body',  'label' => 'Body',  'type' => 'textarea' ],
                                ],
                            ],
                        ],
                    ],
                ],
            ],
            [
                'key'          => 'field_sp_faq',
                'name'         => 'faq',
                'label'        => 'FAQ',
                'type'         => 'repeater',
                'button_label' => 'Add FAQ Item',
                'sub_fields'   => [
                    [ 'key' => 'field_sp_faq_q', 'name' => 'q', 'label' => 'Question', 'type' => 'text' ],
                    [ 'key' => 'field_sp_faq_a', 'name' => 'a', 'label' => 'Answer',   'type' => 'textarea' ],
                ],
            ],
        ],
        'location' => [
            [ [ 'param' => 'post_type', 'operator' => '==', 'value' => 'page' ] ],
        ],
    ] );

    // -----------------------------------------------------------------------
    // Group 2: Detail Page — applied to detail_page CPT
    // -----------------------------------------------------------------------
    acf_import_field_group( [
        'key'          => 'group_ihs_detail_page',
        'title'        => 'Detail Page',
        'active'       => true,
        'show_in_rest' => 1,
        'fields' => [
            [
                'key'          => 'field_dp_slug',
                'name'         => 'slug',
                'label'        => 'Slug (URL)',
                'type'         => 'text',
                'instructions' => 'e.g. alcohol-intervention — must match the URL exactly.',
            ],
            [
                'key'           => 'field_dp_parent_section',
                'name'          => 'parent_section',
                'label'         => 'Parent Section',
                'type'          => 'select',
                'choices'       => [ 'intervention' => 'Intervention', 'services' => 'Services', 'resources' => 'Resources' ],
                'allow_null'    => false,
                'default_value' => 'intervention',
            ],
            [ 'key' => 'field_dp_label',            'name' => 'label',            'label' => 'Label (nav / card text)',                    'type' => 'text' ],
            [
                'key'          => 'field_dp_nav_href_override',
                'name'         => 'nav_href_override',
                'label'        => 'Nav URL override (optional)',
                'type'         => 'text',
                'instructions' => 'Leave blank — nav link auto-generates as /{parent}/{slug}. Set only when the link should point elsewhere, e.g. /interventionists-by-state.',
            ],
            [
                'key'          => 'field_dp_source_page_slug',
                'name'         => 'source_page_slug',
                'label'        => 'Body content source (optional)',
                'type'         => 'text',
                'instructions' => 'Leave blank — the page body pulls from the WP page with this same slug. Set only when the content lives on a differently-named WP page.',
            ],
            [ 'key' => 'field_dp_title',   'name' => 'title',   'label' => 'Title (H1)',                 'type' => 'text' ],
            [ 'key' => 'field_dp_summary', 'name' => 'summary', 'label' => 'Summary (meta description)', 'type' => 'textarea' ],
            [ 'key' => 'field_dp_intro',   'name' => 'intro',   'label' => 'Intro paragraph',            'type' => 'textarea' ],
            [
                'key'           => 'field_dp_image',
                'name'          => 'image',
                'label'         => 'Hero Image',
                'type'          => 'image',
                'return_format' => 'url',
                'preview_size'  => 'medium',
            ],
            [
                'key'          => 'field_dp_content_blocks',
                'name'         => 'content_blocks',
                'label'        => 'Content Blocks',
                'type'         => 'flexible_content',
                'button_label' => 'Add Block',
                'layouts'      => [
                    [
                        'key'        => 'layout_dp_body_block',
                        'name'       => 'body_block',
                        'label'      => 'Body Block',
                        'sub_fields' => [
                            [ 'key' => 'field_dp_bb_heading', 'name' => 'heading', 'label' => 'Heading', 'type' => 'text' ],
                            [ 'key' => 'field_dp_bb_body',    'name' => 'body',    'label' => 'Body',    'type' => 'textarea', 'instructions' => 'Newline = new paragraph.' ],
                        ],
                    ],
                    [
                        'key'        => 'layout_dp_bullets_block',
                        'name'       => 'bullets_block',
                        'label'      => 'Bullets Block',
                        'sub_fields' => [
                            [ 'key' => 'field_dp_bub_heading', 'name' => 'heading', 'label' => 'Heading',                    'type' => 'text' ],
                            [ 'key' => 'field_dp_bub_body',    'name' => 'body',    'label' => 'Intro paragraph (optional)', 'type' => 'textarea' ],
                            [
                                'key'          => 'field_dp_bub_bullets',
                                'name'         => 'bullets',
                                'label'        => 'Bullets',
                                'type'         => 'repeater',
                                'button_label' => 'Add Bullet',
                                'sub_fields'   => [
                                    [ 'key' => 'field_dp_bub_item', 'name' => 'item', 'label' => 'Item', 'type' => 'text' ],
                                ],
                            ],
                        ],
                    ],
                    [
                        'key'        => 'layout_dp_stats_block',
                        'name'       => 'stats_block',
                        'label'      => 'Stats Block',
                        'sub_fields' => [
                            [ 'key' => 'field_dp_stb_heading', 'name' => 'heading', 'label' => 'Heading', 'type' => 'text' ],
                            [ 'key' => 'field_dp_stb_body',    'name' => 'body',    'label' => 'Intro paragraph (optional)', 'type' => 'textarea' ],
                            [
                                'key'          => 'field_dp_stb_stats',
                                'name'         => 'stats',
                                'label'        => 'Stats',
                                'type'         => 'repeater',
                                'button_label' => 'Add Stat',
                                'sub_fields'   => [
                                    [ 'key' => 'field_dp_stb_value', 'name' => 'value', 'label' => 'Value', 'type' => 'text' ],
                                    [ 'key' => 'field_dp_stb_label', 'name' => 'label', 'label' => 'Label', 'type' => 'text' ],
                                ],
                            ],
                        ],
                    ],
                    [
                        'key'        => 'layout_dp_features_block',
                        'name'       => 'features_block',
                        'label'      => 'Features Block',
                        'sub_fields' => [
                            [ 'key' => 'field_dp_fb_heading', 'name' => 'heading', 'label' => 'Heading', 'type' => 'text' ],
                            [ 'key' => 'field_dp_fb_body',    'name' => 'body',    'label' => 'Intro paragraph (optional)', 'type' => 'textarea' ],
                            [
                                'key'          => 'field_dp_fb_features',
                                'name'         => 'features',
                                'label'        => 'Features',
                                'type'         => 'repeater',
                                'button_label' => 'Add Feature',
                                'sub_fields'   => [
                                    [ 'key' => 'field_dp_fb_feat_title', 'name' => 'title', 'label' => 'Title', 'type' => 'text' ],
                                    [ 'key' => 'field_dp_fb_feat_body',  'name' => 'body',  'label' => 'Body',  'type' => 'textarea' ],
                                ],
                            ],
                        ],
                    ],
                    [
                        'key'        => 'layout_dp_steps_block',
                        'name'       => 'steps_block',
                        'label'      => 'Steps Block',
                        'sub_fields' => [
                            [ 'key' => 'field_dp_sb_heading', 'name' => 'heading', 'label' => 'Heading', 'type' => 'text' ],
                            [ 'key' => 'field_dp_sb_body',    'name' => 'body',    'label' => 'Intro paragraph (optional)', 'type' => 'textarea' ],
                            [
                                'key'          => 'field_dp_sb_steps',
                                'name'         => 'steps',
                                'label'        => 'Steps',
                                'type'         => 'repeater',
                                'button_label' => 'Add Step',
                                'sub_fields'   => [
                                    [ 'key' => 'field_dp_sb_step_title', 'name' => 'title', 'label' => 'Title', 'type' => 'text' ],
                                    [ 'key' => 'field_dp_sb_step_body',  'name' => 'body',  'label' => 'Body',  'type' => 'textarea' ],
                                ],
                            ],
                        ],
                    ],
                ],
            ],
            [
                'key'          => 'field_dp_faq',
                'name'         => 'faq',
                'label'        => 'FAQ',
                'type'         => 'repeater',
                'button_label' => 'Add FAQ Item',
                'sub_fields'   => [
                    [ 'key' => 'field_dp_faq_q', 'name' => 'q', 'label' => 'Question', 'type' => 'text' ],
                    [ 'key' => 'field_dp_faq_a', 'name' => 'a', 'label' => 'Answer',   'type' => 'textarea' ],
                ],
            ],
        ],
        'location' => [
            [ [ 'param' => 'post_type', 'operator' => '==', 'value' => 'detail_page' ] ],
        ],
    ] );

    // -----------------------------------------------------------------------
    // Group 3: Global Settings — applied to the Global Settings options page
    // -----------------------------------------------------------------------
    acf_import_field_group( [
        'key'          => 'group_ihs_global_settings',
        'title'        => 'Global Settings',
        'active'       => true,
        'show_in_rest' => 1,
        'fields' => [
            [ 'key' => 'field_gs_phone_display', 'name' => 'phone_display', 'label' => 'Phone (display)', 'type' => 'text',  'placeholder' => '(800) 789-1605' ],
            [ 'key' => 'field_gs_phone_href',    'name' => 'phone_href',    'label' => 'Phone (href)',    'type' => 'text',  'placeholder' => 'tel:+18007891605' ],
            [ 'key' => 'field_gs_email',         'name' => 'email',         'label' => 'Email',           'type' => 'email', 'placeholder' => 'help@intervention.com' ],
            [ 'key' => 'field_gs_revalidate_url',    'name' => 'revalidate_url',    'label' => 'Revalidation: Site URL',    'type' => 'url',  'instructions' => 'Base URL of the deployed Next.js site, e.g. https://intervention.com (no trailing /api). Leave blank to disable.' ],
            [ 'key' => 'field_gs_revalidate_secret', 'name' => 'revalidate_secret', 'label' => 'Revalidation: Secret token', 'type' => 'text', 'instructions' => 'Must match REVALIDATE_SECRET on the Next.js host.' ],
        ],
        'location' => [
            [ [ 'param' => 'options_page', 'operator' => '==', 'value' => 'global-settings' ] ],
        ],
    ] );

    update_option( 'ihs_field_groups_v200_imported', true );
} );
